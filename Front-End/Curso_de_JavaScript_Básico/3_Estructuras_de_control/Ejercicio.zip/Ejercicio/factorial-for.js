let dato = 10;
let resultado = dato;

for (let i = 1; i < dato; i++) {
    resultado = resultado * i;
    console.log(resultado);
}