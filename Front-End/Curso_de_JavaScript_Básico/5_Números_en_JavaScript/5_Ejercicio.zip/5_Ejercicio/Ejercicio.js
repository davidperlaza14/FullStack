/**
 Enunciado del ejercicio:

Crea un archivo JS que contenga las siguientes líneas

- Una variable que contenga tu altura en centímetros (entero)

- Una variable que contenga tu altura en metros (número de coma flotante)

- Una variable que contenga tu peso en kilogramos (número de coma flotante)

- Una variable que contenga tu altura en metros redondeada hacia arriba

- Una variable que contenga tu peso en kilogramos redondeado hacia abajo

- Una variable que contenga si "el máximo valor que se puede obtener en Javascript + 1" es igual al máximo valor que se puede obtener en Javascript
 */


// - Una variable que contenga tu altura en centímetros (entero)
let alturaInt = 178;
console.log(typeof alturaInt);


// - Una variable que contenga tu altura en metros (número de coma flotante)
let alturaFloat = 1.78;
console.log(typeof alturaInt);

// - Una variable que contenga tu peso en kilogramos (número de coma flotante)
let pesoFloat = 71.0;
console.log(typeof pesoFloat);


// - Una variable que contenga tu altura en metros redondeada hacia arriba
console.log(Math.ceil(alturaFloat));


// - Una variable que contenga tu peso en kilogramos redondeado hacia abajo
console.log(Math.floor(pesoFloat));



/** Esta la ultima pregunta no la entendi. */
// - Una variable que contenga si "el máximo valor que se puede obtener en Javascript + 1" es igual al máximo valor que se puede obtener en Javascript

