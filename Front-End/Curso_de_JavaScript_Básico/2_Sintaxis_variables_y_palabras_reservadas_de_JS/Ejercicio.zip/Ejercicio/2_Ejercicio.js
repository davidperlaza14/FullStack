/**
Enunciado del ejercicio:

Crea un nuevo archivo JS que contenga una lista con los siguientes elementos:

- Tu nombre (string)

- Tu edad (number)

- ¿Eres desarrollador? (boolean)

- Tu fecha de nacimiento (Date)

- Tu libro favorito (Objeto con propiedades: titulo, autor, fecha, url)
 */


const Datos = ["David", 29, true, new Date(2023, 11, 14), libroFavorito = {
    titulo: "La Puta de Babilonia",
    autor: "Fernando Vallejo",
    fecha: 2007,
    url: "https://es.wikipedia.org/wiki/La_puta_de_Babilonia"
}]
