"""
Enunciado del ejercicio:

Escribe un programa que sea capaz de mostrar los números del 1 al 100 en orden inverso.
"""

for i in range(100,0, -1 ):
    print(i);